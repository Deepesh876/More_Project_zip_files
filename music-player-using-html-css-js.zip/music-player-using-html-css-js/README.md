# music player using html css and javascript
# redesigned by Jayendra choudhary.
# add songs by yourself and of your choice in folder named "mp3"
# note: that all the songs will be renamed as "1.mp3", "2.mp3", "3.mp3", so on.
# you can add as much songs as you can and for it you had just to add more code to javascript.
# make sure to follow us on: 
# Instagram - https://www.instagram.com/devzone.wiyou
# Join our Telegram channel - https://t.me/devzonebywiyou
# visit our website - https://sites.google.com/view/devzonebywiyou